# Aceros Dusso

Landing estática lista para GitHub y Vercel.

## Estructura
- index.html
- images/proyecto-1.jpeg
- images/proyecto-2.jpeg
- images/proyecto-3.jpeg
- images/proyecto-4.jpeg

## WhatsApp
El sitio abre WhatsApp con un mensaje precargado:

"Hola buenas, estoy interesado en solicitar un presupuesto por trabajos de zinguería y/o sistemas de extracción."
